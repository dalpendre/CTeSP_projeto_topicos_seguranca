﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace ficha2
{
    class servidor
    {
        private const int PORT = 9999;

        static void Main(string[] args)
        {
            TcpListener tcpListener = null;
            TcpClient tcpClient = null;
            NetworkStream networkStream = null;

            try
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Loopback, PORT);
                tcpListener = new TcpListener(endPoint);

                Console.WriteLine("Starting server...");
                tcpListener.Start();

                Console.WriteLine("Waiting for client...");
                tcpClient = tcpListener.AcceptTcpClient();

                Console.WriteLine("Connected to client...");
                networkStream = tcpClient.GetStream();

                #region alinea a)

                int buffer = tcpClient.ReceiveBufferSize;
                byte[] msgbytes = new byte[buffer];
                networkStream.Read(msgbytes, 0, msgbytes.Length);
                Console.WriteLine("Received: " + BitConverter.ToInt32(msgbytes, 0));

                //enviar confirmacao

                byte[] ack = Encoding.UTF8.GetBytes("OK");
                networkStream.Write(ack, 0, ack.Length);
                Console.WriteLine("Sending ok...");

                #endregion

                Console.ReadKey();

                #region alinea b)

                int buffer1 = tcpClient.ReceiveBufferSize;
                byte[] msgbytes1 = new byte[buffer1];
                int byteslidos = networkStream.Read(msgbytes1, 0, msgbytes1.Length);
                Console.WriteLine("Received: " + Encoding.UTF8.GetString(msgbytes1, 0, byteslidos));         


                //enviar confirmacao

                byte[] ack1 = Encoding.UTF8.GetBytes("OK");
                networkStream.Write(ack1, 0, ack1.Length);
                Console.WriteLine("Sending ok...");

                #endregion

                #region alinea c)

                #endregion

                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            finally
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }

                if (networkStream != null)
                {
                    networkStream.Close();
                }
            }
        }
    
    }
}
