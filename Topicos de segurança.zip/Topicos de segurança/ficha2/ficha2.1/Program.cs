﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace ficha2._1
{
    class Program
    {
        private const int PORT = 9999;

        static void Main(string[] args)
        {
            TcpClient tcpClient = null;
            NetworkStream networkStream = null;

            try
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Loopback, PORT);
                tcpClient = new TcpClient();

                Console.WriteLine("Start connection...");
                Console.ReadKey();

                tcpClient.Connect(endPoint);
                networkStream = tcpClient.GetStream();

                Console.WriteLine("Send int message? Press any key");
                Console.ReadKey();

                #region alinea a)

                int msgbox = 142;
                byte[] msgbytes = BitConverter.GetBytes(msgbox);
                networkStream.Write(msgbytes, 0, msgbytes.Length);          

                //receber confirmação

                byte[] ack = new byte[2];
                int byteslidos = networkStream.Read(ack, 0, ack.Length);
                Console.WriteLine(Encoding.UTF8.GetString(ack, 0, byteslidos));

                #endregion

                #region b)

                Console.WriteLine("Send string message? Press any key");
                Console.ReadKey();

                String msgboxS = "Frase";

                msgboxS = Cifrar(msgboxS, 1);


                byte[] msgbytes1 = Encoding.UTF8.GetBytes(msgboxS);
                networkStream.Write(msgbytes1, 0, msgbytes1.Length);

                //receber confirmação

                byte[] ack1 = new byte[2];
                int byteslidos1 = networkStream.Read(ack1, 0, ack1.Length);
                Console.WriteLine(Encoding.UTF8.GetString(ack1, 0, byteslidos1));

                #endregion

            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);               
            }

            finally
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }

                if (networkStream != null)
                {
                    networkStream.Close();
                }
            }
        }

        static String Cifrar(String mensagem, int troca)
        {
            char[] buffer = mensagem.ToCharArray();

            for (int i = 0; i < buffer.Length; i++)
            {
                //Letra
                char letra = buffer[i];
                letra = (char)(letra + troca);

                //Guardar
                buffer[i] = letra;
            }

            return new String(buffer);
        }
    }
}
