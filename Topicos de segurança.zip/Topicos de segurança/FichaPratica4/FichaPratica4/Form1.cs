﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace FichaPratica4
{
    public partial class Form1 : Form
    {

        private RSACryptoServiceProvider rsa;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonGenerateKeys_Click(object sender, EventArgs e)
        {
            rsa = new RSACryptoServiceProvider();

            string publicKey = rsa.ToXmlString(false);
            string privateKey = rsa.ToXmlString(true);

            tbPublicKey.Text = publicKey;
            tbBothKeys.Text = privateKey;
        }

        private void buttonSavePublicKey_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("../../ficheiroPublic.txt");

            sw.Write(tbPublicKey.Text);
            sw.Close();

            MessageBox.Show("Ficheiro criado com sucesso", "ficheiro", MessageBoxButtons.OK, MessageBoxIcon.Information);
          
        }

        private void buttonSavePublicPrivateKey_Click(object sender, EventArgs e)
        {
            // File.WriteAllText("publicKey.txt", tbPublicKey.Text);

            StreamWriter sw = new StreamWriter("../../ficheiroPrivate.txt");

            sw.Write(tbBothKeys.Text + "\t\n\t\n\t\n" + tbPublicKey.Text);
            sw.Close();

            MessageBox.Show("Ficheiro criado com sucesso", "ficheiro", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {

        }
    }
}
