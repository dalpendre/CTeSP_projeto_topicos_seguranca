﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security;
using System.Security.Cryptography;
using System.IO;

namespace TPS___Ficha3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            sa = Rijndael.Create();
        }

        string cipherData;
        byte[] chipherbytes;
        byte[] plainbytes;
        byte[] plainbytes2;


        SymmetricAlgorithm sa;

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text != null)
            {
                Encriptar();
            }
        }

        private void Encriptar()
        {
            plainbytes = Encoding.ASCII.GetBytes(textBox1.Text);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, sa.CreateEncryptor(), 
            CryptoStreamMode.Write);
            cs.Write(plainbytes, 0, plainbytes.Length);
            cs.Close();

            chipherbytes = ms.ToArray();
            ms.Close();

            textBox3.Text = Encoding.ASCII.GetString(chipherbytes);
        }

        private void Desencriptar()
        {
            
            MemoryStream ms1 = new MemoryStream(chipherbytes);
            CryptoStream cs1 = new CryptoStream(ms1, sa.CreateDecryptor(),
            CryptoStreamMode.Read);            byte[] plainbytes1 = new byte[ms1.Length];
            cs1.Read(plainbytes1, 0, plainbytes1.Length);         
            cs1.Close();

            textBox2.Text = Encoding.UTF8.GetString(plainbytes);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Desencriptar();
        }
    }
}
