﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace FichaPratica5_Ex1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonMD5_Click(object sender, EventArgs e)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] originalBytes = ASCIIEncoding.Default.GetBytes(tbData.Text);
            byte[] encodeBytes = md5.ComputeHash(originalBytes);

            tbHash.Text = BitConverter.ToString(encodeBytes).Replace("-", "");
            tbBits.Text = md5.HashSize.ToString();
        }

        private void buttonSHA1_Click(object sender, EventArgs e)
        {
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
            byte[] originalBytes = ASCIIEncoding.Default.GetBytes(tbData.Text);
            byte[] encodeBytes = sha1.ComputeHash(originalBytes);

            tbHash.Text = BitConverter.ToString(encodeBytes).Replace("-", "");
            tbBits.Text = sha1.HashSize.ToString();

        }

        private void buttonSHA512_Click(object sender, EventArgs e)
        {
            SHA512CryptoServiceProvider sha512 = new SHA512CryptoServiceProvider();
            byte[] originalBytes = ASCIIEncoding.Default.GetBytes(tbData.Text);
            byte[] encodeBytes = sha512.ComputeHash(originalBytes);

            tbHash.Text = BitConverter.ToString(encodeBytes).Replace("-", "");
            tbBits.Text = sha512.HashSize.ToString();
        }
    }
}
