﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FichaPratica5_Ex2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();

        private void buttonInput1_Click(object sender, EventArgs e)
        {
            Block(tbInput1.Text, false);
            buttonInput2.Enabled = true;
        }

        private void buttonInput2_Click(object sender, EventArgs e)
        {
            Block(tbInput2.Text, false);
            buttonFinal.Enabled = true;
        }

        private void buttonFinal_Click(object sender, EventArgs e)
        {
            Block(tbInputFinal.Text, true);
            tbHash.Text = BitConverter.ToString(sha1.Hash).Replace("-", " ").ToLower();

        }

        public void Block(string value, bool final)
        {
            byte[] originalBytes = Encoding.UTF8.GetBytes(value);
            if (final)
            {
                sha1.TransformFinalBlock(originalBytes, 0, originalBytes.Length);
            }
            else
            {
                sha1.TransformBlock(originalBytes, 0, originalBytes.Length, originalBytes, 0);
            }
        }
    }
}
