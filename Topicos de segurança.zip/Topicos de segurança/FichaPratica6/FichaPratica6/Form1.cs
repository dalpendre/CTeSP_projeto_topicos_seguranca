﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FichaPratica6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
            rsaSign = new RSACryptoServiceProvider();
            rsaVerify = new RSACryptoServiceProvider();

            byte[] hash = Convert.FromBase64String(tbHashData.Text);
            byte[] signature = Convert.FromBase64String(tbSignature.Text);
        }

        private string publickey;
        private RSACryptoServiceProvider rsaSign;
        private RSACryptoServiceProvider rsaVerify;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            

          
        }

        private void buttonGenerate_Click(object sender, EventArgs e)
        {
           

            publickey = rsaSign.ToXmlString(false);


            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] data = Encoding.UTF8.GetBytes(tbDataToSign.Text);
                byte[] hash = sha256.ComputeHash(data);

                tbHashData.Text = Convert.ToBase64String(hash).Replace("-", "");
                tbBitsHashData.Text = (hash.Length * 8).ToString();

            }
        }

        private void buttonSignHash_Click(object sender, EventArgs e)
        {
            byte[] hash = Convert.FromBase64String(tbHashData.Text);
            byte[] signature = rsaSign.SignHash(hash, CryptoConfig.MapNameToOID("SHA256"));

            tbSignature.Text = Convert.ToBase64String(signature);
            tbBitsSignature.Text = (signature.Length * 8).ToString();
        }

        private void buttonVerifyHash_Click(object sender, EventArgs e)
        {
            rsaVerify.FromXmlString(publickey);

            byte[] hash = Convert.FromBase64String(tbHashData.Text);
            byte[] signature = Convert.FromBase64String(tbSignature.Text);

            bool result = rsaVerify.VerifyHash(hash, CryptoConfig.MapNameToOID("SHA256"), signature);

            tbIsVerified.Text = result.ToString();



        }

        private void tbIsVerified_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonSignData_Click(object sender, EventArgs e)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] data = Convert.FromBase64String(tbHashData.Text);
                byte[] signature = rsaSign.SignData(data, sha256);

                tbSignature.Text = Convert.ToBase64String(signature);
                tbBitsSignature.Text = (signature.Length * 8).ToString();
            }
                
        }
    }
}
