﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Definiar variaveis locais

            int bufferSize = 20480;
            byte[] buffer = new byte[bufferSize];
            int bytesRead = 0;
            String originalFilePath = "security.jpg";
            String copyFilePath = "copy_security.jpg";

            //Verificar se o ficheiro ja existe

            if (File.Exists(copyFilePath))
              {
                File.Delete(copyFilePath);
              }

            //Criar controladores de ficheiros

            FileStream originalFileStream = new FileStream(originalFilePath, FileMode.Open);
            FileStream copyFileStream = new FileStream(copyFilePath, FileMode.Create);

            //Copiar conteudos 

            while((bytesRead = originalFileStream.Read(buffer, 0, bufferSize)) > 0)
            {
                copyFileStream.Write(buffer, 0, bytesRead);
            }

            //mostrar mensagem ao utilizador

            label1.Visible = true;

            //Libertar recursos


        }
    }
}
