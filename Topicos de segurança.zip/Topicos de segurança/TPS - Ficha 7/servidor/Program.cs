﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using EI.SI;
using System.Threading;

namespace servidor
{
    class Program
    {
        private const int PORT = 9999;

        static void Main(string[] args)
        {
            
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Loopback, PORT);
            TcpListener listener = new TcpListener(endPoint);
            int clientCounter = 0;
            listener.Start();

            while (true)
            {
                TcpClient tcpClient = listener.AcceptTcpClient();
                clientCounter++;
                Console.WriteLine("Client (0) connected", clientCounter);

                NetworkStream networkStream = tcpClient.GetStream();
                ProtocolSI protocolSI = new ProtocolSI();
                networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                Console.WriteLine(protocolSI.GetStringFromData());

                ClientHandler clientHandler = new ClientHandler(tcpClient, clientCounter);
                clientHandler.Handle();

               
            }

            Console.ReadKey();
        }

        class ClientHandler
        {
            private TcpClient client;
            private int clientID;

            public ClientHandler(TcpClient client, int clientID)
            {
                this.client = client;
                this.clientID = clientID;
            }

            public void Handle()
            {
                Thread thread = new Thread(threadHandler);
                thread.Start();
            }

            private void threadHandler()
            {
                NetworkStream networkStream = client.GetStream();
                ProtocolSI protocolSI = new ProtocolSI();
                networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                Console.WriteLine(protocolSI.GetStringFromData());

                 
            }
        }
    }
}
