﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using EI.SI;
using System.Threading;

namespace TPS___Ficha_7
{
    public partial class Form1 : Form
    {
        private const int PORT = 9999;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Loopback, PORT);
            TcpClient tcpClient = new TcpClient();

            tcpClient.Connect(endPoint);
            NetworkStream networkStream = tcpClient.GetStream();

            ProtocolSI protocolSI = new ProtocolSI();
            byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, textBox1.Text);
            networkStream.Write(packet, 0, packet.Length);

           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
